package ConnectionManager;

import java.sql.*;

/**
 * Created by jls on 2/10/15.
 */
public class ConnectionManager {

    private static String URL = "jdbc:mysql://82.171.46.128:3306/test";
    private static String username;
    private static String password;

    private static boolean interrupt = false;
    private static Connection connection = null;
//    private static boolean verified = false;

    public static String getURL() {
        return URL;
    }

    public static void setURL(String URL) {
        ConnectionManager.URL = URL;
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        ConnectionManager.username = username;
    }

//    public static String getPassword() {
//        return password;
//    }

    public static void setPassword(String password) {
        ConnectionManager.password = password;
    }

    public static Connection getConnection(String url, String username, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, username, password);
        } catch (ClassNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return connection;
    }

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, username, password);
        } catch (ClassNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return connection;
    }

    public static void setLoginCredentials(String username, String password) {
        ConnectionManager.username = username;
        ConnectionManager.password = password;
    }

    public static void startCheckConnectionLoop() throws InterruptedException {
        while (!interrupt) {
            ConnectionManager.getConnection();
            Thread.sleep(60 * 1000);
        }
    }

    public static void stopCheckConnectionLoop() {
        interrupt = true;
    }
}
