package Controller;

import DisplayManager.Display;

import javax.swing.*;

/**
 * Created by jls on 2/10/15.
 */
public class Driver {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Display();
            }
        });
    }
}
