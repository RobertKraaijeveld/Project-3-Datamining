package DisplayManager;

import javax.swing.*;
import java.awt.*;

/**
 * Created by jls on 2/15/15.
 */
public class ResultPanel extends JPanel {

    private GridBagConstraints gbc;
    private JTable resultTable;

    public ResultPanel() {
        super(new GridBagLayout());
        // Initialize
        initComponents();
        // Create
        createComponents();
        createPanel();
        // Listen
        setVisible(false);
    }

    private void initComponents() {
        // Tables
        resultTable = new JTable(8,4);
        // GridBagConstraints + Insets
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 5, 5, 5);
    }

    private void createComponents() {
        resultTable.setEnabled(false);
        resultTable.setBackground(Color.LIGHT_GRAY);
        resultTable.setGridColor(Color.DARK_GRAY);
        resultTable.setVisible(true);
    }

    private void createPanel() {
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.WEST;
        this.add(resultTable, gbc);
    }
}
