package DisplayManager;

import javax.swing.*;
import java.awt.*;

/**
 * Created by jls on 2/9/15.
 */

public class Display extends JFrame {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 400;

    private JMenuBar menu;

    private JMenu file;
    private JMenuItem connect;
    private JMenuItem disconnect;
    private JMenuItem print;
    private JMenuItem exit;

    public Display() {
        super(" Social Media Statics ");
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
        }
        // Initialize
        initMenu();
        // Create
        createMenu();
        createDisplay();
        // Listen
        menuListener();
    }

    private void initMenu() {
        menu = new JMenuBar();
        file = new JMenu(" File ");
        connect = new JMenuItem(" Connect ");
        disconnect = new JMenuItem(" Disconnect ");
        print = new JMenuItem(" Print ");
        exit = new JMenuItem(" Exit ");
    }

    private void createMenu() {
        file.add(connect);
        disconnect.setEnabled(false);
        file.add(disconnect);
        file.addSeparator();
        file.add(print);
        file.addSeparator();
        file.add(exit);
        menu.add(file);
    }

    private void createDisplay() {
        this.setJMenuBar(menu);
        this.setLayout(new BorderLayout());
        this.setSize(new Dimension(WIDTH, HEIGHT));
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(new SelectionPanel(), BorderLayout.NORTH);
        this.setVisible(true);
    }

    private void menuListener() {
//        connect.addActionListener(e -> connectionStatus = connectionEstablished() ? "Disconnect" : "Connect");
        disconnect.addActionListener(e -> System.out.println("Create disconnect from database method"));
        print.addActionListener(e -> System.out.println("Create print results"));
        exit.addActionListener(e -> System.exit(0));
    }
}
