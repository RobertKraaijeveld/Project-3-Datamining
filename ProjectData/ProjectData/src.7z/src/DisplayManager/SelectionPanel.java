package DisplayManager;

import Calendar.DatePicker;
import ConnectionManager.ConnectionManager;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;

/**
 * Created by jls on 2/15/15.
 */
public class SelectionPanel extends JPanel {

    private GridBagConstraints gbc;

    private JComboBox mediaBox;

    private JLabel endDate;
    private JLabel startDate;
    private JLabel selectMedia;
    private JLabel reminderOne;
    private JLabel reminderTwo;
    private JLabel reminderThree;
    private JLabel username;
    private JLabel password;

    private JButton findButton;
    private JButton loginButton;

    private JTextField userBox;
    private JPasswordField passBox;

    private DatePicker startDateBox;
    private DatePicker endDateBox;

    private ResultPanel resultTabel;

    private String[] media = {"Twitter", "Foursquare", "Facebook"};

    public SelectionPanel() {
        super(new GridBagLayout());
        // Initialize
        initComponents();
        // Create
        createComponents();
        createPanel();
        // Listen
        datePickerListener();
        buttonListener();
    }

    private void initComponents() {
        // Labels
        username = new JLabel("Username:", JLabel.LEFT);
        password = new JLabel("Password:", JLabel.LEFT);
        startDate = new JLabel("Start Date:", JLabel.LEFT);
        endDate = new JLabel("End Date:", JLabel.LEFT);
        selectMedia = new JLabel("Select your media:", JLabel.LEFT);
        reminderOne = new JLabel("This field can't be empty!", JLabel.LEFT);
        reminderTwo = new JLabel("This field can't be empty!", JLabel.LEFT);
        reminderThree = new JLabel("This field can't be empty!", JLabel.LEFT);
        // Buttons
        findButton = new JButton(" Find >> ");
        loginButton = new JButton(" Login ");
        // TextFields
        userBox = new JTextField();
        // PasswordFields
        passBox = new JPasswordField();
        // ComboBoxes
        mediaBox = new JComboBox(media);
        // DatePickers
        startDateBox = new DatePicker();
        endDateBox = new DatePicker();
        // ResultPanel
        resultTabel = new ResultPanel();
        // GridBagConstraints + Insets
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 30, 5);
    }

    private void createComponents() {
        // Labels
        reminderOne.setVisible(false);
        reminderTwo.setVisible(false);
        reminderThree.setVisible(false);
        // Buttons
        findButton.setPreferredSize(new Dimension(100, 25));
        loginButton.setPreferredSize(new Dimension(100, 25));
        // TextFields
        userBox.setPreferredSize(new Dimension(200, 25));
        // PasswordFields
        passBox.setPreferredSize(new Dimension(200, 25));
        // ComboBoxes
        mediaBox.setPreferredSize(new Dimension(200, 25));
        // ResultPanel
        resultTabel.setVisible(false); // Init as false only when results are retrieved change to true
    }

    private void createPanel() {
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.anchor = GridBagConstraints.WEST;
        this.add(username, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(userBox, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(password, gbc);

        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(passBox, gbc);

        gbc.gridx = 4;
        gbc.gridy = 0;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(loginButton, gbc);

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(reminderOne, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0; // no growing fat
        gbc.weighty = 0; // no growing tall
        this.add(startDate, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0; // no growing fat
        gbc.weighty = 0; // no growing tall
        this.add(startDateBox.getDatePicker(), gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(reminderTwo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0; // no growing fat
        gbc.weighty = 0; // no growing tall
        this.add(endDate, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(endDateBox.getDatePicker(), gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(reminderThree, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0;
        gbc.weighty = 0;
        this.add(selectMedia, gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0; // no growing fat
        gbc.weighty = 0; // no growing tall
        this.add(mediaBox, gbc);

        gbc.gridx = 2;
        gbc.gridy = 6;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0; // no growing fat
        gbc.weighty = 0; // no growing tall
        this.add(findButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.gridheight = 1;
        gbc.weightx = 0; // no growing fat
        gbc.weighty = 0; // no growing tall
        gbc.fill = GridBagConstraints.BOTH;
        this.add(resultTabel, gbc);

        this.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.DARK_GRAY), "Selection Panel"));
    }

    // Return text from a TextComponent
    public String returnField(JTextComponent t) {
        String string = "";
        if (t instanceof JPasswordField) {
            for (Object s : ((JPasswordField) t).getPassword()) {
                string += s;
            }
        } else {
            string = t.getText();
        }
        return string;
    }

    // clears the Fields
    public void clearFields() {
        for (Component c : this.getComponents()) {
            if (c instanceof JTextComponent) {
                ((JTextComponent) c).setText("");
            }
        }
    }

    public boolean emptyFields() {
        boolean emptyField = true;
        for (Component c : this.getComponents()) {
            if (c instanceof JTextComponent) {
                if (((JTextComponent) c).getText() != "") {
                    emptyField = false;
                }
            }
        }
        return emptyField;
    }

    private void login() {
        String username = returnField(userBox);
        String password = returnField(passBox);
        ConnectionManager.setLoginCredentials(username, password);
        if (ConnectionManager.getConnection() != null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        ConnectionManager.startCheckConnectionLoop();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            loggedInStatus();
        } else {
            loggedOutStatus();
        }
    }

    private void loggedInStatus() {
        JOptionPane.showMessageDialog(this, " Successfully logged in!");
        this.username.setVisible(false);
        this.password.setVisible(false);
        this.passBox.setVisible(false);
        this.userBox.setVisible(false);
        this.loginButton.setText(" Welcome, " + returnField(userBox) + "!");
        this.loginButton.setPreferredSize(new Dimension(200, 25));
        this.loginButton.setEnabled(false);
    }

    private void loggedOutStatus() {
        JOptionPane.showMessageDialog(this, "Failed to log in!");
        clearFields();
        this.username.setVisible(true);
        this.password.setVisible(true);
        this.passBox.setVisible(true);
        this.userBox.setVisible(true);
        this.loginButton.setText(" Login ");
        this.loginButton.setPreferredSize(new Dimension(100, 25));
        this.loginButton.setEnabled(true);
    }

    private void datePickerListener() {
        startDateBox.getDatePicker().addActionListener(e -> System.out.println(startDateBox.getDatePicker().getModel().getValue()));
        endDateBox.getDatePicker().addActionListener(e -> System.out.println(endDateBox.getDatePicker().getModel().getValue()));
    }

    private void buttonListener() {
        loginButton.addActionListener(e -> login());
        // TODO add query to grab the dates and retrieve information
    }
}
